import tornado
import tornado.web

import uuid
import json
class FileHandler(tornado.web.RequestHandler):
    
    def set_default_headers(self):
        
        self.set_header("Access-Control-Allow-Origin", "*")
        self.set_header("Access-Control-Allow-Headers", "x-requested-with")
        self.set_header('Access-Control-Allow-Methods', 'POST, GET, OPTIONS')
        
    def post(self):
        print(len(self.request.body))
        filename="nofile"
        for field_name,files in self.request.files.items():
            for info in files:
                
                filename,content_type=info['filename'],info['content_type']
                print(filename+"\n\n")
                body=info['body']
        self.finish(json.dumps({  "keys":[{ "key":filename,"val":"val1" },{ "key":"key2","val":"val2" }],"text":"lots of text" }))

        # temp_file_name = str(uuid.uuid4()) + filename
        # # self.finish(json.loads('{"returnval":{"key":"val"}}'))
        #
        # with open(temp_file_name, "wb") as f:
        #     f.write(body)
        # tag=get_text(temp_file_name)
        # self.finish(json.dumps(tag))
        # if logger.level != 10:
        #     os.remove(temp_file_name)
application =tornado.web.Application(

    [

        (r"/file",FileHandler),


    ],debug=True

)


http_server=tornado.httpserver.HTTPServer(application)
http_server.listen(8000)    
http_server.start()

tornado.ioloop.IOLoop.current().start()